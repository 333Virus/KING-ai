# KING AI

Yellow/black browser AI chat interface.

Upload these files to the `main` branch of your GitHub repository.

For GitHub Pages:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

This version is a frontend demo and does not expose an AI API key.
